const express = require("express");
const multer = require("multer");
const { extractGps, matchFamous } = require("./identify");
const catalog = require("./catalog");

const router = express.Router();

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter(req, file, cb) {
    const typeOk = /image\/(jpeg|png|webp|heic|heif)/i.test(file.mimetype);
    const nameOk = /\.(jpe?g|png|webp|heic|heif)$/i.test(file.originalname || "");
    if (typeOk || nameOk) {
      cb(null, true);
      return;
    }
    cb(new Error("Please upload a JPEG, PNG, WebP, or HEIC photo."));
  },
});

function render(res, extra = {}, status = 200) {
  res.status(status).render("monuments", {
    error: extra.error || null,
    latest: extra.latest || null,
    entries: catalog.list(),
  });
}

router.get("/", (req, res) => {
  render(res);
});

router.post("/upload", (req, res) => {
  upload.single("photo")(req, res, async (err) => {
    if (err) {
      const message =
        err.code === "LIMIT_FILE_SIZE"
          ? "Photo must be 5MB or smaller."
          : err.message || "Could not upload that photo.";
      return render(res, { error: message }, 400);
    }

    if (!req.file) {
      return render(res, { error: "Choose a photo to upload." }, 400);
    }

    try {
      const gps = await extractGps(req.file.buffer);
      if (!gps) {
        return render(
          res,
          {
            error:
              "This photo has no location data. Enable camera location and try another file.",
          },
          400
        );
      }

      const match = matchFamous(gps.lat, gps.lon);
      if (!match) {
        return render(
          res,
          {
            error: "This photo's location does not match a famous monument in our list.",
          },
          400
        );
      }

      const latest = catalog.add({
        ...match,
        lat: gps.lat,
        lon: gps.lon,
        buffer: req.file.buffer,
        originalName: req.file.originalname,
      });
      return render(res, { latest });
    } catch (error) {
      return render(res, { error: "Could not read that photo." }, 400);
    }
  });
});

module.exports = router;
