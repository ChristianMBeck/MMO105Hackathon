const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const DATA_DIR = path.join(__dirname, "data");
const PHOTOS_DIR = path.join(DATA_DIR, "photos");
const CATALOG_PATH = path.join(DATA_DIR, "monuments.json");
const ALLOWED_EXT = new Set([".jpg", ".jpeg", ".png", ".webp", ".heic", ".heif"]);

function ensureDirs() {
  fs.mkdirSync(PHOTOS_DIR, { recursive: true });
  if (!fs.existsSync(CATALOG_PATH)) {
    fs.writeFileSync(CATALOG_PATH, "[]\n");
  }
}

function list() {
  ensureDirs();
  try {
    const parsed = JSON.parse(fs.readFileSync(CATALOG_PATH, "utf8"));
    return Array.isArray(parsed) ? parsed : [];
  } catch (err) {
    return [];
  }
}

function add({ famousId, name, country, lat, lon, distanceMeters, buffer, originalName }) {
  ensureDirs();
  const id = crypto.randomUUID();
  const ext = path.extname(originalName || "").toLowerCase();
  const safeExt = ALLOWED_EXT.has(ext) ? ext : ".jpg";
  const filename = `${id}${safeExt}`;
  fs.writeFileSync(path.join(PHOTOS_DIR, filename), buffer);

  const record = {
    id,
    famousId,
    name,
    country,
    lat,
    lon,
    distanceMeters,
    photoPath: filename,
    createdAt: new Date().toISOString(),
  };

  const items = list();
  items.unshift(record);
  fs.writeFileSync(CATALOG_PATH, JSON.stringify(items, null, 2));
  return record;
}

module.exports = { list, add, PHOTOS_DIR };
